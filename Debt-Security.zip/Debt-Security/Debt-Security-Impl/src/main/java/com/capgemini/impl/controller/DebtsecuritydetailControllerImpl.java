package com.capgemini.impl.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.DebtsecuritydetailController;
import com.capgemini.impl.model.Holding;
import com.capgemini.impl.model.SecurityType;
import com.capgemini.impl.repository.DebtSecurityRepository;
import com.capgemini.model.DebtSecurity;


@RestController
public class DebtsecuritydetailControllerImpl implements DebtsecuritydetailController {

	@Autowired
	private DebtSecurityRepository repository;

	
	/*For security type of DebtSecurity pass the types as "ds"
	 * 
	 * 
	 * */
	@Override
	@GetMapping("/{HoldingId}")
	public ResponseEntity<DebtSecurity> getDebtSecurityBy(
	        @PathVariable("HoldingId")
	        String holdingId,
	        @RequestParam(name = "SecurityType")
	        String securityType) {
		System.out.println("in method");
		if (securityType!= null && SecurityType.DEBT.toString().equals(securityType) ) {
			Optional<Holding> holding = repository.findById(holdingId);
			return new ResponseEntity<DebtSecurity>(holding.get().getSecurityDetails(),HttpStatus.OK);
		}
		return null;
	}
	
	@GetMapping("/get/{holdingId}")
	public String getNames(@PathVariable String holdingId) {
		System.out.println("in");
		return "Done";
	}



	
	
}
