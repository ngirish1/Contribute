package com.capgemini.impl.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.PersistenceConstructor;
import org.springframework.data.mongodb.core.mapping.Document;

import com.capgemini.model.DebtSecurity;


@Document(collection="Holding")
public class Holding {
	
	@Id
	private String HoldingId;
	private SecurityType securityType;
	private DebtSecurity SecurityDetails;
	
	public Holding(String holdingId, SecurityType securityType, DebtSecurity securityDetails) {
		super();
		HoldingId = holdingId;
		this.securityType = securityType;
		SecurityDetails = securityDetails;
	}

	
	public String getHoldingId() {
		return HoldingId;
	}
	public SecurityType getSecurityType() {
		return securityType;
	}
	public void setSecurityType(SecurityType securityType) {
		this.securityType = securityType;
	}
	public DebtSecurity getSecurityDetails() {
		return SecurityDetails;
	}
	public void setSecurityDetails(DebtSecurity securityDetails) {
		SecurityDetails = securityDetails;
	}
	public void setHoldingId(String holdingId) {
		HoldingId = holdingId;
	}
	
	  @Override
		public String toString() {
			return "Holding [HoldingId=" + HoldingId + ", securityType=" + securityType + ", SecurityDetails="
					+ SecurityDetails + "]";
		}
	
}
