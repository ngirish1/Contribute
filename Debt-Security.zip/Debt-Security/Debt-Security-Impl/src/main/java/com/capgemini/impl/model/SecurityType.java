package com.capgemini.impl.model;

public enum SecurityType {
	DEBT("ds"),
	MUTUALFUND("mf"),
	OPTION("op"),
	OTHER("oth"),
	STOCK("st"),
	SWEEP("sw");
	
private String text;
	
SecurityType(String text){
		this.text=text;
	}
	
	@Override
	public String toString() {
		return text;
		
	}
}
