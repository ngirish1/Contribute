package com.capgemini.impl.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

import com.capgemini.impl.model.Holding;


@EnableMongoRepositories
public interface DebtSecurityRepository extends MongoRepository<Holding,String> {



	
}
